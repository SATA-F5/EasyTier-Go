package com.easytier.fabric.lan.client;

import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;

/**
 * 带淡灰色提示文字的输入框
 * 提示文字使用 0x808080 灰色，与原生输入文字形成对比度
 *
 * 注意：不要在 write 中做全局字符过滤。
 * 数字限制只允许通过 {@link #setNumericOnly(boolean)} 显式开启，
 * 避免网络名称、中继地址、密码等文本字段被误设成只能输入数字。
 */
public class PlaceholderTextFieldWidget extends class_342 {

    private static final int PLACEHOLDER_COLOR = 0x808080;
    private final class_327 textRendererRef;
    private class_2561 placeholderText;
    private boolean numericOnly = false;

    public PlaceholderTextFieldWidget(class_327 textRenderer, int x, int y, int width, int height, class_2561 text) {
        super(textRenderer, x, y, width, height, text);
        this.textRendererRef = textRenderer;
        // 默认允许所有字符；只有端口字段会显式切换到纯数字过滤
        this.method_1890(value -> true);
    }

    @Override
    public void method_47404(class_2561 placeholder) {
        this.placeholderText = placeholder;
        super.method_47404(placeholder);
    }

    /**
     * 仅端口等数字字段需要调用；默认关闭，文本字段保持自由输入。
     */
    public void setNumericOnly(boolean numericOnly) {
        this.numericOnly = numericOnly;
        this.method_1890(numericOnly ? value -> value.matches("[0-9]*") : value -> true);
    }

    public boolean isNumericOnly() {
        return numericOnly;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        if (this.method_1882().isEmpty() && placeholderText != null && !this.method_25370()) {
            String text = placeholderText.getString();
            if (!text.isEmpty()) {
                int color = this.field_22763 ? PLACEHOLDER_COLOR : 0x606060;
                context.method_25303(textRendererRef, text,
                        this.method_46426() + 4, this.method_46427() + (this.field_22759 - 8) / 2, color);
            }
        }
    }
}
