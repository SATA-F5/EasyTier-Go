package com.easytier.fabric.lan.client;

import com.easytier.fabric.lan.EasyTierService;
import com.easytier.fabric.lan.config.FileSanitizer;
import com.easytier.fabric.lan.config.TomlConfig;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5676;
import net.minecraft.class_7842;

/**
 * EasyTier 联机配置界面（自适应布局）
 * 左栏：运行日志（上）+ 配置选择列表（下）
 * 右栏：编辑区 + 开关 + 连接地址 + 复制按钮
 * 底部：两行操作按钮
 * 日志支持垂直+水平滚动，所有坐标基于 this.width/this.height 计算
 */
public class EasyTierConfigScreen extends class_437 {

    private final class_437 parent;
    private final EasyTierService service;

    // 左栏
    private int logX, logY, logW, logH;
    private ConfigListWidget configList;
    private final List<String> logLines = new ArrayList<>();
    private static final int MAX_LOG_LINES = 1000;
    private int logVScroll = 0;
    private int logHScroll = 0;
    private volatile int logMaxLineWidth = 0;

    // 右栏
    private PlaceholderTextFieldWidget networkNameField;
    private PlaceholderTextFieldWidget relayServerField;
    private PlaceholderTextFieldWidget networkSecretField;
    private PlaceholderTextFieldWidget devNameField;
    private PlaceholderTextFieldWidget virtualPortField;
    private class_5676<Boolean> portForwardToggle;
    private class_5676<Boolean> autoRefreshToggle;
    private class_7842 forwardAddressText;
    private class_7842 statusText;
    private class_7842 fileNameText;
    private String currentInstanceId;
    private String currentFileName = "";
    private String selectedNetwork = "";

    // 界面重新 init（窗口缩放、从状态面板返回、下载确认返回）时用于恢复用户输入
    private boolean hasDraftState = false;
    private String draftNetworkName = "";
    private String draftRelayServer = "";
    private String draftNetworkSecret = "";
    private String draftDevName = "";
    private String draftVirtualPort = "25565";
    private String draftInstanceId = "";
    private boolean draftPortForward = true;
    private boolean draftAutoRefresh = false;

    // 左栏底部地址区
    private int addrAreaX, addrAreaY, addrAreaW, addrAreaH;

    // 操作按钮
    private class_4185 startButton;
    private class_4185 stopButton;
    private class_4185 refreshButton;
    private class_4185 applyPortForwardBtn;

    // 自适应布局常量
    private static final int MARGIN = 6;
    private static final int GAP = 3;
    private static final int TITLE_H = 20;
    private static final int FIELD_H = 18;
    private static final int LABEL_H = 10;
    private static final int BTN_ROW_H = 20;
    private static final int LOG_BG = 0xFF000000;
    private static final int LOG_TEXT = 0xFFFFFFFF;
    private static final int LABEL_COLOR = 0x909090;
    private static final int MIN_LEFT_W = 100;
    private static final int MIN_RIGHT_W = 200;
    private static final int LOG_TITLE_H = 12;
    private static final int SCROLLBAR_W = 4;

    private int autoRefreshCounter = 0;
    private boolean refreshing = false;
    private volatile boolean portForwardEnabled = true;
    private volatile int autoApplyToken = 0;
    private int leftPanelW;
    private int rightPanelX;
    private int rightPanelW;
    private String errorMessage = null;
    private long errorMessageTime = 0;

    public EasyTierConfigScreen(class_437 parent) {
        super(class_2561.method_43470("EasyTier 联机配置"));
        this.parent = parent;
        this.service = EasyTierService.getInstance();
    }

    @Override
    protected void method_25426() {
        // ===== 自适应面板宽度计算 =====
        leftPanelW = Math.max(MIN_LEFT_W, (int) (this.field_22789 * 0.30));
        rightPanelX = MARGIN + leftPanelW + GAP * 2;
        rightPanelW = this.field_22789 - rightPanelX - MARGIN;
        if (rightPanelW < MIN_RIGHT_W) {
            leftPanelW = Math.max(100, this.field_22789 - MIN_RIGHT_W - MARGIN * 2 - GAP * 2);
            rightPanelX = MARGIN + leftPanelW + GAP * 2;
            rightPanelW = this.field_22789 - rightPanelX - MARGIN;
        }

        int contentTop = TITLE_H + GAP;
        int bottomReserve = BTN_ROW_H * 2 + GAP * 3 + 4;
        int availableH = this.field_22790 - contentTop - bottomReserve;
        if (availableH < 120) availableH = 120;

        // ===== 右栏高度预计算与自适应压缩 =====
        int idealRightH = (LABEL_H + GAP * 2)                    // 状态行
                + (LABEL_H + 1 + FIELD_H + GAP) * 4              // 4组标签+输入框
                + (FIELD_H + GAP);                               // 开关行

        int dynGap = GAP;
        int dynFieldH = FIELD_H;
        int dynLabelH = LABEL_H;
        if (idealRightH > availableH) {
            double ratio = (double) availableH / idealRightH;
            dynGap = Math.max(1, (int) (GAP * ratio));
            dynFieldH = Math.max(14, (int) (FIELD_H * ratio));
            dynLabelH = Math.max(8, (int) (LABEL_H * ratio));
        }
        final int fGap = dynGap;
        final int fFieldH = dynFieldH;
        final int fLabelH = dynLabelH;

        // ===== 左栏区域划分 =====
        // 日志 50%，配置列表 28%，地址区 22%
        int logAreaH = (int) (availableH * 0.50);
        int listAreaTotalH = (int) (availableH * 0.28);
        int addrAreaH = availableH - logAreaH - listAreaTotalH - fGap * 2;

        // 日志区域
        logX = MARGIN;
        logY = contentTop;
        logW = leftPanelW;
        logH = Math.max(50, logAreaH);

        // 配置列表区域（缩小）
        int listAreaY = logY + logH + fGap;
        int listTitleY = listAreaY;
        int listY = listTitleY + LOG_TITLE_H + 1;
        int listH = Math.max(30, listAreaTotalH - LOG_TITLE_H - 1);

        configList = new ConfigListWidget(this.field_22787, leftPanelW, listH, listY, listY + listH, 16,
                name -> onConfigSelected(name));
        configList.method_25333(logX);
        this.method_37063(configList);

        // 转发地址区（左栏底部）
        addrAreaX = logX;
        addrAreaY = listY + listH + fGap;
        addrAreaW = leftPanelW;
        addrAreaH = Math.max(40, addrAreaH);

        int addrY = addrAreaY + 2;
        forwardAddressText = new class_7842(addrAreaX + 3, addrY, addrAreaW - 6, fLabelH,
                class_2561.method_43470("转发地址: 未获取虚拟IP"), this.field_22793);
        forwardAddressText.method_48596();
        this.method_37063(forwardAddressText);
        addrY += fLabelH + 2;

        int copyBtnW = (addrAreaW - fGap - 6) / 2;
        addButtonDyn(addrAreaX + 3, addrY, copyBtnW, fFieldH, "复制IP", btn -> copyVirtualIp());
        addButtonDyn(addrAreaX + 3 + copyBtnW + fGap, addrY, copyBtnW, fFieldH, "复制地址", btn -> copyConnectionAddress());

        // ===== 右栏：编辑区 =====
        int rx = rightPanelX;
        int ry = contentTop;
        int fieldW = rightPanelW;
        int halfW = (fieldW - fGap) / 2;

        // 状态 + 文件名（同行）
        statusText = new class_7842(rx, ry, halfW, fLabelH,
                class_2561.method_43470("状态: 检测中..."), this.field_22793);
        statusText.method_48596();
        this.method_37063(statusText);
        fileNameText = new class_7842(rx + halfW + fGap, ry, halfW, fLabelH,
                class_2561.method_43470(""), this.field_22793);
        fileNameText.method_48596();
        this.method_37063(fileNameText);
        ry += fLabelH + fGap * 2;

        // 网络名称
        ry = addLabelDyn(rx, ry, "网络名称", fieldW, fLabelH);
        networkNameField = addTextFieldDyn(rx, ry, fieldW, fFieldH, "my-mc-network");
        networkNameField.method_1880(32);
        ry += fFieldH + fGap;

        // 中继服务器
        ry = addLabelDyn(rx, ry, "中继服务器 (host:port)", fieldW, fLabelH);
        relayServerField = addTextFieldDyn(rx, ry, fieldW, fFieldH, "public.easytier.cn:11010");
        relayServerField.method_1880(128);
        ry += fFieldH + fGap;

        // 网络密码
        ry = addLabelDyn(rx, ry, "网络密码 (留空表示无密码)", fieldW, fLabelH);
        networkSecretField = addTextFieldDyn(rx, ry, fieldW, fFieldH, "");
        networkSecretField.method_1880(128);
        ry += fFieldH + fGap;

        // 网卡名 + 虚拟端口（同行）
        ry = addLabelDyn(rx, ry, "网卡名", halfW, fLabelH);
        devNameField = addTextFieldDyn(rx, ry, halfW, fFieldH, "et_fabric");
        devNameField.method_1880(32);
        addLabelDyn(rx + halfW + fGap, ry - fLabelH - 1, "虚拟端口", halfW, fLabelH);
        virtualPortField = addTextFieldDyn(rx + halfW + fGap, ry, halfW, fFieldH, "25565");
        virtualPortField.method_1880(5);
        virtualPortField.setNumericOnly(true);
        virtualPortField.method_1852("25565");
        ry += fFieldH + fGap;

        // 开关行：端口转发 + 自动刷新
        int toggleW = (fieldW - fGap) / 2;
        portForwardToggle = addCyclingDyn(rx, ry, toggleW, fFieldH,
                List.of(true, false), true, "端口转发",
                (btn, val) -> onPortForwardToggle(val));
        portForwardEnabled = true;
        autoRefreshToggle = addCyclingDyn(rx + toggleW + fGap, ry, toggleW, fFieldH,
                List.of(false, true), false, "自动刷新",
                (btn, val) -> {});

        // 实例 ID 内部生成
        currentInstanceId = TomlConfig.generateInstanceId();
        updateFileNamePreview();

        // 加载配置列表
        refreshConfigList();

        // ===== 底部操作按钮（两行，跨全宽） =====
        int btnY1 = this.field_22790 - BTN_ROW_H * 2 - fGap * 2 - 2;
        int btnY2 = this.field_22790 - BTN_ROW_H - fGap - 2;

        int fullW = this.field_22789 - MARGIN * 2;
        int btnW4 = (fullW - fGap * 3) / 4;
        if (btnW4 < 60) btnW4 = 60;
        int btnW5 = (fullW - fGap * 4) / 5;
        if (btnW5 < 50) btnW5 = 50;
        int bx = MARGIN;
        startButton = addButtonDyn(bx, btnY1, btnW4, BTN_ROW_H, "启动", btn -> onToggleStartStop());
        bx += btnW4 + fGap;
        addButtonDyn(bx, btnY1, btnW4, BTN_ROW_H, "状态面板", btn -> {
            if (this.field_22787 != null) {
                this.field_22787.method_1507(new EasyTierStatusScreen(this, service.getBaseDir()));
            }
        });
        bx += btnW4 + fGap;
        refreshButton = addButtonDyn(bx, btnY1, btnW4, BTN_ROW_H, "刷新", btn -> onRefresh());
        bx += btnW4 + fGap;
        addButtonDyn(bx, btnY1, btnW4, BTN_ROW_H, "中继服务器列表", btn -> onOpenRelayList());

        applyPortForwardBtn = addButtonDyn(MARGIN, btnY2, btnW5, BTN_ROW_H, "端口转发", btn -> onApplyPortForward());
        addButtonDyn(MARGIN + (btnW5 + fGap), btnY2, btnW5, BTN_ROW_H, "保存配置", btn -> onSaveConfig());
        addButtonDyn(MARGIN + (btnW5 + fGap) * 2, btnY2, btnW5, BTN_ROW_H, "删除配置", btn -> onDeleteConfig());
        addButtonDyn(MARGIN + (btnW5 + fGap) * 3, btnY2, btnW5, BTN_ROW_H, "清理进程", btn -> {
            service.cleanupAllProcesses();
            appendLog("[INFO] 已执行清理所有 EasyTier 进程");
        });
        addButtonDyn(MARGIN + (btnW5 + fGap) * 4, btnY2, btnW5, BTN_ROW_H, "关闭", btn -> onClose());

        // 日志回调
        service.getLogManager().setUiCallback(line -> appendLog(line));

        // 平台不支持
        if (!service.isPlatformSupported()) {
            startButton.field_22763 = false;
            appendLog("[ERROR] 当前平台不支持 EasyTier");
            if (service.isAndroid()) {
                appendLog("[ERROR] Android 不支持，请使用 EasyTier 官方 Android 应用");
            }
        }

        updateButtonStates();
    }

    // ==================== 配置列表 ====================

    private void refreshConfigList() {
        List<String> networks = safeListNetworks();
        String sel = selectedNetwork.isEmpty() ? (networks.isEmpty() ? "" : networks.get(0)) : selectedNetwork;
        configList.updateEntries(networks, sel);
    }

    private List<String> safeListNetworks() {
        try {
            List<String> networks = service.listNetworks();
            return networks != null ? networks : new ArrayList<>();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    private void onConfigSelected(String name) {
        if (networkNameField == null || relayServerField == null) return;
        selectedNetwork = name;
        TomlConfig latest = service.getConfig(name);
        if (latest != null) {
            networkNameField.method_1852(latest.getNetworkName() != null ? latest.getNetworkName() : name);
            relayServerField.method_1852(latest.getRelayServer() != null ? latest.getRelayServer() : "");
            networkSecretField.method_1852(latest.getNetworkSecret() != null ? latest.getNetworkSecret() : "");
            devNameField.method_1852(latest.getDevName() != null ? latest.getDevName() : "et_fabric");
            currentInstanceId = latest.getInstanceId() != null ? latest.getInstanceId() : TomlConfig.generateInstanceId();
            appendLog("[INFO] 已加载配置: " + name);
        } else {
            networkNameField.method_1852(name);
            appendLog("[INFO] 新建配置: " + name);
        }
        updateFileNamePreview();
    }

    // ==================== 事件处理（异步） ====================

    private void onToggleStartStop() {
        if (service.isRunning() || service.isStartPending()) {
            onStop();
        } else {
            onStart();
        }
    }

    private void onStart() {
        String name = networkNameField.method_1882().trim();
        String relay = relayServerField.method_1882().trim();

        if (name.isEmpty()) {
            appendLog("[ERROR] 网络名称不能为空");
            return;
        }
        if (relay.isEmpty()) {
            appendLog("[ERROR] 中继服务器不能为空");
            return;
        }
        if (service.isStartPending()) {
            appendLog("[WARN] 启动任务正在执行中，请稍候");
            return;
        }

        // 下载知情同意：如果 EasyTier 二进制不存在，先询问用户
        if (!service.getProcessManager().isBinaryReady()) {
            showDownloadConfirm(name, relay);
            return;
        }

        doStart(name, relay);
    }

    /**
     * 显示下载确认对话框
     */
    private void showDownloadConfirm(String name, String relay) {
        if (this.field_22787 == null) return;
        net.minecraft.class_410 confirm = new net.minecraft.class_410(
                confirmed -> {
                    if (confirmed) {
                        appendLog("[INFO] 用户已同意下载 EasyTier CLI");
                        doStart(name, relay);
                        if (this.field_22787 != null) {
                            this.field_22787.method_1507(this);
                        }
                    } else {
                        appendLog("[INFO] 用户取消下载");
                        this.field_22787.method_1507(this);
                    }
                },
                class_2561.method_43470("需要下载 EasyTier CLI"),
                class_2561.method_43470("首次使用需要从 GitHub 下载 EasyTier 核心程序（约 10-20MB）。\n"
                        + "下载源：GitHub Releases（通过 13 个镜像加速，最后回退原链接）。\n"
                        + "下载后将计算 SHA256 并记录到日志。\n\n"
                        + "是否继续？"),
                class_2561.method_43470("确认下载"),
                class_2561.method_43470("取消")
        );
        this.field_22787.method_1507(confirm);
    }

    private void doStart(String name, String relay) {
        String secret = networkSecretField.method_1882().trim();
        String devName = devNameField.method_1882().trim();
        final String vPortText = virtualPortField != null ? virtualPortField.method_1882().trim() : "";
        final boolean portForwardRequested = portForwardToggle != null && portForwardToggle.method_32603();

        appendLog("[INFO] 正在启动 EasyTier（异步）...");
        startButton.field_22763 = false;
        startButton.method_25355(class_2561.method_43470("启动中..."));

        service.startAsync(name, relay, secret, devName, true)
                .thenAccept(ok -> runOnClientThread(() -> {
                    if (ok != null && ok) {
                        appendLog("[INFO] EasyTier 启动成功，等待虚拟IP分配...");
                        clearError();
                        // 启动成功后自动应用端口转发（如果开关开启）
                        if (portForwardRequested) {
                            appendLog("[INFO] 端口转发已启用，将在虚拟IP分配后自动配置...");
                            int token = ++autoApplyToken;
                            autoApplyPortForward(vPortText, token);
                        }
                    } else {
                        showError("EasyTier 启动失败，请查看日志详情");
                    }
                    updateButtonStates();
                }))
                .exceptionally(ex -> {
                    StringBuilder err = new StringBuilder("启动异常: " + ex.getMessage());
                    Throwable cause = ex.getCause();
                    while (cause != null) {
                        err.append(" | 原因: ").append(cause.getClass().getSimpleName()).append(": ").append(cause.getMessage());
                        cause = cause.getCause();
                    }
                    runOnClientThread(() -> {
                        showError(err.toString());
                        updateButtonStates();
                    });
                    return null;
                });
    }

    private void runOnClientThread(Runnable action) {
        if (this.field_22787 != null) {
            this.field_22787.execute(action);
        } else {
            action.run();
        }
    }

    private void onStop() {
        if (!service.isRunning()) {
            appendLog("[WARN] EasyTier 未运行");
            return;
        }
        appendLog("[INFO] 正在停止 EasyTier（异步）...");
        startButton.field_22763 = false;
        autoApplyToken++;
        service.stopAsync().thenRun(() -> runOnClientThread(() -> {
            appendLog("[INFO] EasyTier 已停止");
            updateButtonStates();
        })).exceptionally(ex -> {
            runOnClientThread(() -> {
                showError("停止异常: " + ex.getMessage());
                updateButtonStates();
            });
            return null;
        });
    }

    private void onRefresh() {
        if (!service.isRunning()) {
            appendLog("[WARN] EasyTier 未运行");
            return;
        }
        if (refreshing) {
            return;
        }
        refreshing = true;
        appendLog("[INFO] 正在刷新节点信息（异步）...");
        refreshButton.field_22763 = false;
        service.refreshAsync().thenAccept(ip -> {
            String nodeInfo;
            String peerInfo;
            try {
                nodeInfo = service.getCliRunner().node();
            } catch (Exception e) {
                nodeInfo = "[ERROR] node 查询失败: " + e.getMessage();
            }
            try {
                peerInfo = service.getCliRunner().peer();
            } catch (Exception e) {
                peerInfo = "[ERROR] peer 查询失败: " + e.getMessage();
            }
            final String finalNodeInfo = nodeInfo;
            final String finalPeerInfo = peerInfo;
            runOnClientThread(() -> {
                appendLog("---- 节点信息 ----");
                appendLog(finalNodeInfo == null || finalNodeInfo.isEmpty() ? "(无输出)" : finalNodeInfo);
                appendLog(finalPeerInfo == null || finalPeerInfo.isEmpty() ? "(无输出)" : finalPeerInfo);
                if (ip != null) {
                    appendLog("[INFO] 当前虚拟IP: " + ip);
                }
                updateAddressDisplay();
                refreshing = false;
                updateButtonStates();
            });
        }).exceptionally(ex -> {
            runOnClientThread(() -> {
                appendLog("[ERROR] 刷新失败: " + ex.getMessage());
                refreshing = false;
                updateButtonStates();
            });
            return null;
        });
    }

    private void onOpenRelayList() {
        class_156.method_668().method_670("https://info.qtet.cn/uptime/easytier");
    }

    private void onApplyPortForward() {
        if (!service.isRunning()) {
            appendLog("[ERROR] EasyTier 未运行，无法应用端口转发");
            return;
        }
        String ip = service.getVirtualIp();
        if (ip == null || ip.isEmpty()) {
            appendLog("[ERROR] 虚拟IP未获取，请等待或点击刷新");
            return;
        }
        int mcPort = getMinecraftPort();
        if (mcPort <= 0) {
            appendLog("[ERROR] 未检测到 Minecraft 局域网端口，请先对局域网开放");
            return;
        }
        if (!portForwardToggle.method_32603()) {
            appendLog("[INFO] 端口转发已禁用，仅显示直连地址");
            return;
        }
        int vPort;
        String vPortStr = virtualPortField.method_1882().trim();
        if (vPortStr.isEmpty()) {
            appendLog("[ERROR] 虚拟端口不能为空，请输入 1-65535 之间的端口号");
            return;
        }
        try {
            vPort = Integer.parseInt(vPortStr);
        } catch (NumberFormatException e) {
            appendLog("[ERROR] 虚拟端口格式错误: '" + vPortStr + "'，请输入纯数字（1-65535）");
            return;
        }
        if (vPort < 1 || vPort > 65535) {
            appendLog("[ERROR] 虚拟端口超出范围: " + vPort + "，有效范围 1-65535");
            return;
        }
        boolean ok = service.getProcessManager().addPortForward("tcp", vPort, ip, mcPort);
        if (ok) {
            appendLog("[INFO] 端口转发已添加: tcp 0.0.0.0:" + vPort + " -> " + ip + ":" + mcPort);
            appendLog("[INFO] 好友连接地址: " + ip + ":" + vPort);
        } else {
            appendLog("[ERROR] 端口转发添加失败");
        }
        updateAddressDisplay();
    }

    /**
     * 自动应用端口转发：后台等待虚拟IP分配，然后自动添加转发
     */
    private void autoApplyPortForward(String vPortStr, int token) {
        new Thread(() -> {
            try {
                // 等待虚拟IP分配，最多15秒
                String ip = null;
                for (int i = 0; i < 15; i++) {
                    Thread.sleep(1000);
                    if (token != autoApplyToken || !service.isRunning()) {
                        return;
                    }
                    ip = service.getVirtualIp();
                    if (ip != null && !ip.isEmpty()) {
                        break;
                    }
                }
                if (token != autoApplyToken) {
                    return;
                }
                if (ip == null || ip.isEmpty()) {
                    appendLog("[WARN] 自动端口转发：虚拟IP分配超时，请手动点击刷新后再应用端口转发");
                    return;
                }
                if (!portForwardEnabled) {
                    appendLog("[INFO] 自动端口转发：端口转发开关已关闭，跳过");
                    return;
                }

                // 检测 Minecraft 集成服务器端口（等待期间用户可能刚开启局域网）
                int mcPort = getMinecraftPort();
                if (mcPort <= 0) {
                    appendLog("[INFO] 自动端口转发：未检测到 Minecraft 局域网端口（请先对局域网开放），跳过自动转发");
                    return;
                }

                // 解析虚拟端口，为空或格式错误时回退到默认 25565
                int vPort = 25565;
                if (vPortStr != null && !vPortStr.isEmpty()) {
                    try {
                        int parsed = Integer.parseInt(vPortStr);
                        if (parsed >= 1 && parsed <= 65535) {
                            vPort = parsed;
                        } else {
                            appendLog("[WARN] 自动端口转发：虚拟端口超出范围 " + parsed + "，使用默认 25565");
                        }
                    } catch (NumberFormatException e) {
                        appendLog("[WARN] 自动端口转发：虚拟端口格式错误 '" + vPortStr + "'，使用默认 25565");
                    }
                }

                // 添加端口转发
                boolean ok = service.getProcessManager().addPortForward("tcp", vPort, ip, mcPort);
                if (ok) {
                    appendLog("[INFO] 自动端口转发成功: tcp 0.0.0.0:" + vPort + " -> " + ip + ":" + mcPort);
                    appendLog("[INFO] 好友连接地址: " + ip + ":" + vPort);
                    runOnClientThread(this::updateAddressDisplay);
                } else {
                    appendLog("[ERROR] 自动端口转发失败，请手动点击端口转发按钮重试");
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }, "easytier-auto-portforward").start();
    }

    private void onSaveConfig() {
        String name = networkNameField.method_1882().trim();
        if (name.isEmpty()) {
            appendLog("[ERROR] 请先填写网络名称");
            return;
        }
        TomlConfig config = buildConfigFromUi();
        if (service.getConfigManager().saveConfig(config)) {
            appendLog("[INFO] 已保存配置: " + config.toFileName());
            refreshConfigList();
            selectedNetwork = name;
            configList.updateEntries(safeListNetworks(), name);
        } else {
            appendLog("[ERROR] 保存失败");
        }
    }

    private void onDeleteConfig() {
        String name = networkNameField.method_1882().trim();
        if (name.isEmpty()) return;

        if (service.isRunning() && service.getProcessManager().getCurrentConfig() != null) {
            TomlConfig running = service.getProcessManager().getCurrentConfig();
            if (name.equalsIgnoreCase(running.getNetworkName())) {
                appendLog("[ERROR] 正在运行的配置无法删除，请先停止");
                return;
            }
        }

        boolean deleted = service.getConfigManager().deleteConfig(name);
        if (deleted) {
            appendLog("[INFO] 已删除配置: " + name);
            refreshConfigList();
            selectedNetwork = "";
        } else {
            appendLog("[ERROR] 删除失败");
        }
    }

    private void onClose() {
        if (service.isRunning()) {
            appendLog("[INFO] EasyTier 将在后台继续运行");
        }
        service.getLogManager().setUiCallback(null);
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }

    private void onPortForwardToggle(boolean enabled) {
        portForwardEnabled = enabled;
        virtualPortField.field_22763 = enabled;
        if (applyPortForwardBtn != null) {
            applyPortForwardBtn.field_22763 = enabled && service.isRunning();
        }
    }

    // ==================== 辅助方法 ====================

    private TomlConfig buildConfigFromUi() {
        String name = networkNameField.method_1882().trim();
        TomlConfig config = new TomlConfig();
        TomlConfig existing = service.getConfig(name);
        if (existing != null && !existing.isCorrupted()) {
            // 保留手工编辑过的 listeners / 静态 IP 设置，避免保存时丢失
            config.setListeners(existing.getListeners());
            config.setManualIpv4(existing.getManualIpv4());
            config.setDhcp(existing.isDhcp());
        } else {
            config.setDhcp(true);
        }
        config.setNetworkName(name);
        config.setInstanceName(name);
        config.setInstanceId(currentInstanceId);
        config.setRelayServer(relayServerField.method_1882().trim());
        config.setNetworkSecret(networkSecretField.method_1882().trim());
        config.setDevName(devNameField.method_1882().trim());
        return config;
    }

    private int getMinecraftPort() {
        if (this.field_22787 != null && this.field_22787.method_1576() != null) {
            return this.field_22787.method_1576().method_3756();
        }
        return -1;
    }

    private void copyVirtualIp() {
        String ip = service.getVirtualIp();
        if (ip == null || ip.isEmpty()) {
            appendLog("[WARN] 虚拟IP未获取");
            return;
        }
        this.field_22787.field_1774.method_1455(ip);
        appendLog("[INFO] 已复制虚拟IP: " + ip);
    }

    private void copyConnectionAddress() {
        String ip = service.getVirtualIp();
        if (ip == null || ip.isEmpty()) {
            appendLog("[WARN] 虚拟IP未获取");
            return;
        }
        String addr;
        if (portForwardToggle.method_32603()) {
            addr = ip + ":" + virtualPortField.method_1882().trim();
        } else {
            int mcPort = getMinecraftPort();
            addr = ip + ":" + (mcPort > 0 ? mcPort : 25565);
        }
        this.field_22787.field_1774.method_1455(addr);
        appendLog("[INFO] 已复制连接地址: " + addr);
    }

    private void updateAddressDisplay() {
        if (forwardAddressText == null) return;
        String ip = service.getVirtualIp();
        if (ip == null || ip.isEmpty()) {
            forwardAddressText.method_25355(class_2561.method_43470("转发地址: 未获取虚拟IP"));
            return;
        }
        String vPort = virtualPortField != null ? virtualPortField.method_1882().trim() : "25565";
        forwardAddressText.method_25355(class_2561.method_43470("转发地址: " + ip + ":" + vPort));
    }

    private void updateFileNamePreview() {
        String name = networkNameField != null ? networkNameField.method_1882().trim() : "";
        String safe = FileSanitizer.sanitize(name);
        currentFileName = safe + ".toml";
        if (fileNameText != null) {
            fileNameText.method_25355(class_2561.method_43470("文件: " + currentFileName));
        }
    }

    private void updateButtonStates() {
        if (startButton == null) return;
        boolean running = service.isRunning();
        boolean pending = service.isStartPending();
        startButton.field_22763 = service.isPlatformSupported() && !pending;
        if (pending) {
            startButton.method_25355(class_2561.method_43470("启动中..."));
        } else if (running) {
            startButton.method_25355(class_2561.method_43470("停止"));
        } else {
            startButton.method_25355(class_2561.method_43470("启动"));
        }
        refreshButton.field_22763 = running && !refreshing;
        applyPortForwardBtn.field_22763 = running && portForwardToggle.method_32603();
    }

    // ==================== 布局辅助 ====================

    private int addLabel(int x, int y, String text) {
        class_7842 widget = new class_7842(x, y, rightPanelW, LABEL_H,
                class_2561.method_43470(text), this.field_22793);
        widget.method_48596();
        this.method_37063(widget);
        return y + LABEL_H + 1;
    }

    private PlaceholderTextFieldWidget addTextField(int x, int y, int w, int h, String placeholder) {
        PlaceholderTextFieldWidget field = new PlaceholderTextFieldWidget(this.field_22793, x, y, w, h, class_2561.method_43470(""));
        field.method_47404(class_2561.method_43470(placeholder));
        this.method_37063(field);
        return field;
    }

    private class_4185 addButton(int x, int y, int w, int h, String text, class_4185.class_4241 action) {
        class_4185 btn = class_4185.method_46430(class_2561.method_43470(text), action)
                .method_46434(x, y, w, h).method_46431();
        this.method_37063(btn);
        return btn;
    }

    private <T> class_5676<T> addCycling(int x, int y, int w, int h,
                                                   List<T> values, T initial, String key,
                                                   class_5676.class_5678<T> callback) {
        class_5676<T> btn = class_5676.<T>method_32606(val -> class_2561.method_43470(val.toString()))
                .method_32620(values)
                .method_32619(initial)
                .method_32617(x, y, w, h, class_2561.method_43470(key), callback);
        this.method_37063(btn);
        return btn;
    }

    // ===== 动态尺寸辅助方法（适配 4:3 等窄屏） =====

    private int addLabelDyn(int x, int y, String text, int w, int labelH) {
        class_7842 widget = new class_7842(x, y, w, labelH,
                class_2561.method_43470(text), this.field_22793);
        widget.method_48596();
        this.method_37063(widget);
        return y + labelH + 1;
    }

    private PlaceholderTextFieldWidget addTextFieldDyn(int x, int y, int w, int h, String placeholder) {
        PlaceholderTextFieldWidget field = new PlaceholderTextFieldWidget(this.field_22793, x, y, w, h, class_2561.method_43470(""));
        field.method_47404(class_2561.method_43470(placeholder));
        this.method_37063(field);
        return field;
    }

    private class_4185 addButtonDyn(int x, int y, int w, int h, String text, class_4185.class_4241 action) {
        class_4185 btn = class_4185.method_46430(class_2561.method_43470(text), action)
                .method_46434(x, y, w, h).method_46431();
        this.method_37063(btn);
        return btn;
    }

    private <T> class_5676<T> addCyclingDyn(int x, int y, int w, int h,
                                                      List<T> values, T initial, String key,
                                                      class_5676.class_5678<T> callback) {
        class_5676<T> btn = class_5676.<T>method_32606(val -> class_2561.method_43470(val.toString()))
                .method_32620(values)
                .method_32619(initial)
                .method_32617(x, y, w, h, class_2561.method_43470(key), callback);
        this.method_37063(btn);
        return btn;
    }

    private void appendLog(String line) {
        final String logLine = line != null ? line : "";
        synchronized (logLines) {
            logLines.add(logLine);
            while (logLines.size() > MAX_LOG_LINES) {
                logLines.remove(0);
            }
        }
        // TextRenderer 只能在客户端线程访问，宽度计算统一调度回渲染线程
        Runnable updateWidth = () -> {
            int w = this.field_22793.method_1727(logLine);
            if (w > logMaxLineWidth) {
                logMaxLineWidth = w;
            }
        };
        if (this.field_22787 != null) {
            this.field_22787.execute(updateWidth);
        } else {
            int w = logLine.length() * 6;
            if (w > logMaxLineWidth) {
                logMaxLineWidth = w;
            }
        }
    }

    private void showError(String msg) {
        this.errorMessage = msg;
        this.errorMessageTime = System.currentTimeMillis();
        appendLog("[ERROR] " + msg);
    }

    private void clearError() {
        this.errorMessage = null;
    }

    // ==================== 渲染 ====================

    @Override
    public void method_25394(net.minecraft.class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 6, 0xFFFFFF);

        // 状态文字更新
        if (statusText != null) {
            boolean running = service.isRunning();
            String status = running ? "运行中" : (service.isStartPending() ? "启动中..." : "已停止");
            int statusColor = running ? 0x55FF55 : (service.isStartPending() ? 0xFFFF55 : 0xFF5555);
            statusText.method_25355(class_2561.method_43470("状态: " + status));
            statusText.method_46438(statusColor);
        }

        super.method_25394(context, mouseX, mouseY, delta);

        // ===== 日志区域渲染 =====
        renderLogArea(context);

        // ===== 配置列表标题（绘制在列表控件上方，不重叠） =====
        if (configList != null) {
            int titleY = configList.getTopY() - LOG_TITLE_H - 1;
            context.method_25294(logX, titleY, logX + logW, titleY + LOG_TITLE_H, 0xFF1A1A1A);
            context.method_49601(logX, titleY, logW, LOG_TITLE_H, 0xFF333333);
            context.method_25303(this.field_22793, "配置列表", logX + 4, titleY + 2, LABEL_COLOR);
        }
    }

    private void renderLogArea(net.minecraft.class_332 context) {
        // 背景
        context.method_25294(logX, logY, logX + logW, logY + logH, LOG_BG);
        context.method_49601(logX, logY, logW, logH, 0xFF444444);

        // 标题栏（在日志区域内部顶部）
        context.method_25294(logX, logY, logX + logW, logY + LOG_TITLE_H, 0xFF1A1A1A);
        context.method_25303(this.field_22793, "运行日志", logX + 4, logY + 2, 0xAAAAAA);

        // 错误提示（标题栏右侧，红色闪烁）
        if (errorMessage != null && !errorMessage.isEmpty()) {
            long elapsed = System.currentTimeMillis() - errorMessageTime;
            if (elapsed < 15000) {
                boolean blink = (elapsed / 500) % 2 == 0;
                int errColor = blink ? 0xFFFF5555 : 0xFFAA0000;
                String errLabel = "错误!";
                int labelW = this.field_22793.method_1727(errLabel);
                context.method_25303(this.field_22793, errLabel, logX + logW - labelW - 4, logY + 2, errColor);
            } else {
                errorMessage = null;
            }
        }

        // 日志文本区域（标题栏下方）
        int textTop = logY + LOG_TITLE_H + 1;
        int textH = logH - LOG_TITLE_H - 2;
        int lineH = this.field_22793.field_2000 + 1;
        int visibleLines = Math.max(1, textH / lineH);

        // 水平滚动范围限制
        int maxHScroll = Math.max(0, logMaxLineWidth - (logW - 8));
        if (logHScroll > maxHScroll) logHScroll = maxHScroll;
        if (logHScroll < 0) logHScroll = 0;

        // 启用裁剪，防止日志文本溢出区域
        context.method_44379(logX, textTop, logX + logW, textTop + textH);
        try {
            synchronized (logLines) {
                int startIdx = Math.max(0, logLines.size() - visibleLines - logVScroll);
                int endIdx = Math.min(logLines.size(), startIdx + visibleLines);
                int drawY = textTop;
                for (int i = startIdx; i < endIdx; i++) {
                    String line = logLines.get(i);
                    int color = LOG_TEXT;
                    if (line.contains("[ERROR]")) color = 0xFF5555;
                    else if (line.contains("[WARN]")) color = 0xFFAA00;
                    else if (line.contains("[INFO]")) color = 0x55FF55;
                    context.method_25303(this.field_22793, line, logX + 3 - logHScroll, drawY, color);
                    drawY += lineH;
                }
            }
        } finally {
            context.method_44380();
        }

        // 垂直滚动条（右侧）
        int totalLines;
        synchronized (logLines) {
            totalLines = logLines.size();
        }
        if (totalLines > visibleLines) {
            int scrollbarX = logX + logW - SCROLLBAR_W - 1;
            int scrollbarY = textTop;
            int scrollbarH = textH;
            int thumbH = Math.max(8, (int) ((long) scrollbarH * visibleLines / totalLines));
            int thumbY = scrollbarY + (int) ((long) (scrollbarH - thumbH) * logVScroll / Math.max(1, totalLines - visibleLines));
            context.method_25294(scrollbarX, scrollbarY, scrollbarX + SCROLLBAR_W, scrollbarY + scrollbarH, 0xFF333333);
            context.method_25294(scrollbarX, thumbY, scrollbarX + SCROLLBAR_W, thumbY + thumbH, 0xFF666666);
        }

        // 水平滚动条（底部）
        if (logMaxLineWidth > logW - 8) {
            int hScrollbarY = logY + logH - SCROLLBAR_W - 1;
            int hScrollbarX = logX + 2;
            int hScrollbarW = logW - 4;
            int hThumbW = Math.max(20, (int) ((long) hScrollbarW * (logW - 8) / logMaxLineWidth));
            int hThumbX = hScrollbarX + (int) ((long) (hScrollbarW - hThumbW) * logHScroll / Math.max(1, maxHScroll));
            context.method_25294(hScrollbarX, hScrollbarY, hScrollbarX + hScrollbarW, hScrollbarY + SCROLLBAR_W, 0xFF333333);
            context.method_25294(hThumbX, hScrollbarY, hThumbX + hThumbW, hScrollbarY + SCROLLBAR_W, 0xFF666666);
        }
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double amount) {
        // 日志区域滚动
        if (mouseX >= logX && mouseX <= logX + logW && mouseY >= logY && mouseY <= logY + logH) {
            int textTop = logY + LOG_TITLE_H + 1;
            int textH = logH - LOG_TITLE_H - 2;
            int lineH = this.field_22793.field_2000 + 1;
            int visibleLines = Math.max(1, textH / lineH);
            int totalLines;
            synchronized (logLines) {
                totalLines = logLines.size();
            }
            int maxVScroll = Math.max(0, totalLines - visibleLines);

            if (method_25442()) {
                // Shift + 滚轮 = 水平滚动
                int maxHScroll = Math.max(0, logMaxLineWidth - (logW - 8));
                logHScroll = Math.max(0, Math.min(maxHScroll, logHScroll - (int) (amount * 20)));
            } else {
                // 普通滚轮 = 垂直滚动（向上滚=查看更早日志，logVScroll增大）
                logVScroll = Math.max(0, Math.min(maxVScroll, logVScroll + (int) amount));
            }
            return true;
        }
        return super.method_25401(mouseX, mouseY, amount);
    }

    private boolean draggingVScroll = false;
    private boolean draggingHScroll = false;

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        int textTop = logY + LOG_TITLE_H + 1;
        int textH = logH - LOG_TITLE_H - 2;
        int lineH = this.field_22793.field_2000 + 1;
        int visibleLines = Math.max(1, textH / lineH);
        int totalLines;
        synchronized (logLines) {
            totalLines = logLines.size();
        }

        // 垂直滚动条点击/拖动
        if (totalLines > visibleLines) {
            int scrollbarX = logX + logW - SCROLLBAR_W - 1;
            if (mouseX >= scrollbarX && mouseX <= scrollbarX + SCROLLBAR_W
                    && mouseY >= textTop && mouseY <= textTop + textH) {
                draggingVScroll = true;
                updateVScrollFromMouse(mouseY, textTop, textH, visibleLines, totalLines);
                return true;
            }
        }

        // 水平滚动条点击/拖动
        if (logMaxLineWidth > logW - 8) {
            int hScrollbarY = logY + logH - SCROLLBAR_W - 1;
            if (mouseX >= logX + 2 && mouseX <= logX + logW - 2
                    && mouseY >= hScrollbarY && mouseY <= hScrollbarY + SCROLLBAR_W) {
                draggingHScroll = true;
                updateHScrollFromMouse(mouseX);
                return true;
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        int textTop = logY + LOG_TITLE_H + 1;
        int textH = logH - LOG_TITLE_H - 2;
        int lineH = this.field_22793.field_2000 + 1;
        int visibleLines = Math.max(1, textH / lineH);
        int totalLines;
        synchronized (logLines) {
            totalLines = logLines.size();
        }

        if (draggingVScroll && totalLines > visibleLines) {
            updateVScrollFromMouse(mouseY, textTop, textH, visibleLines, totalLines);
            return true;
        }
        if (draggingHScroll) {
            updateHScrollFromMouse(mouseX);
            return true;
        }
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        draggingVScroll = false;
        draggingHScroll = false;
        return super.method_25406(mouseX, mouseY, button);
    }

    private void updateVScrollFromMouse(double mouseY, int textTop, int textH, int visibleLines, int totalLines) {
        int thumbH = Math.max(8, (int) ((long) textH * visibleLines / totalLines));
        int maxThumbY = textH - thumbH;
        double ratio = Math.max(0, Math.min(1, (mouseY - textTop - thumbH / 2.0) / maxThumbY));
        int maxVScroll = totalLines - visibleLines;
        logVScroll = (int) (ratio * maxVScroll);
    }

    private void updateHScrollFromMouse(double mouseX) {
        int hScrollbarX = logX + 2;
        int hScrollbarW = logW - 4;
        int maxHScroll = Math.max(0, logMaxLineWidth - (logW - 8));
        double ratio = Math.max(0, Math.min(1, (mouseX - hScrollbarX) / hScrollbarW));
        logHScroll = (int) (ratio * maxHScroll);
    }

    @Override
    public void method_25393() {
        super.method_25393();
        if (startButton != null) {
            updateButtonStates();
        }
        updateAddressDisplay();
        updateFileNamePreview();

        if (autoRefreshToggle != null && autoRefreshToggle.method_32603() && service.isRunning()) {
            autoRefreshCounter++;
            if (autoRefreshCounter >= 100) {
                autoRefreshCounter = 0;
                onRefresh();
            }
        }
    }

    @Override
    public void method_25419() {
        service.getLogManager().setUiCallback(null);
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }
}
