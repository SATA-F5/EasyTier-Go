package com.easytier.fabric.lan.client;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_350;
import net.minecraft.class_6382;

/**
 * 配置选择列表控件
 * 以可滚动列表形式展示所有网络配置，替代原来的下拉按钮
 */
public class ConfigListWidget extends class_350<ConfigListWidget.ConfigEntry> {

    private final Consumer<String> selectionCallback;
    private final int topY;

    public ConfigListWidget(class_310 client, int width, int height, int top, int bottom,
                            int itemHeight, Consumer<String> selectionCallback) {
        super(client, width, height, top, bottom, itemHeight);
        this.selectionCallback = selectionCallback;
        this.topY = top;
    }

    public int getTopY() {
        return topY;
    }

    public void updateEntries(List<String> networkNames, String selected) {
        this.method_25314(List.of());
        for (String name : networkNames) {
            ConfigEntry entry = new ConfigEntry(name);
            this.method_25321(entry);
            if (name.equals(selected)) {
                this.setSelected(entry);
            }
        }
    }

    @Override
    public void setSelected(ConfigEntry entry) {
        super.method_25313(entry);
        if (entry != null && selectionCallback != null) {
            selectionCallback.accept(entry.name);
        }
    }

    @Override
    protected int method_25329() {
        return this.field_19087 - 6;
    }

    @Override
    public int method_25322() {
        return this.field_22742 - 12;
    }

    @Override
    public void method_37020(class_6382 builder) {
        ConfigEntry selected = this.method_25334();
        if (selected != null) {
            builder.method_37034(net.minecraft.class_6381.field_33791,
                    class_2561.method_43470("配置: " + selected.name));
        }
    }

    public class ConfigEntry extends class_350.class_351<ConfigEntry> {
        final String name;

        ConfigEntry(String name) {
            this.name = name;
        }

        @Override
        public void render(class_332 context, int index, int y, int x, int entryWidth,
                           int entryHeight, int mouseX, int mouseY, boolean hovered, float tickDelta) {
            int color = hovered ? 0xFFFFFF : 0xC0C0C0;
            if (ConfigListWidget.this.method_25334() == this) {
                color = 0x55FF55;
            }
            context.method_25303(field_22740.field_1772, name, x + 4, y + 4, color);
            // 提示
            context.method_27535(field_22740.field_1772, class_2561.method_43470("点击加载"),
                    x + entryWidth - 60, y + 4, 0x808080);
        }

        @Override
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            if (button == 0) {
                ConfigListWidget.this.setSelected(this);
                return true;
            }
            return false;
        }
    }
}
