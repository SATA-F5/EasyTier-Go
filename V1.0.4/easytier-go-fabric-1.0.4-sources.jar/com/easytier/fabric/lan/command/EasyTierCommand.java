package com.easytier.fabric.lan.command;

import com.easytier.fabric.lan.EasyTierService;
import com.easytier.fabric.lan.config.ConfigManager;
import com.easytier.fabric.lan.config.FileSanitizer;
import com.easytier.fabric.lan.config.TomlConfig;
import com.easytier.fabric.lan.process.EasyTierCliRunner;
import com.easytier.fabric.lan.process.EasyTierProcessManager;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.server.MinecraftServer;
import java.util.List;
import java.util.Map;

/**
 * /easytier 服务端指令
 * 权限等级 2（管理员/OP）
 *
 * 指令树:
 * /easytier start <network_name> <relay_server> [network_secret]
 * /easytier stop
 * /easytier status
 * /easytier peer
 * /easytier node
 * /easytier route
 * /easytier portforward add <tcp|udp> <bind_port> <virtual_ip> <mc_port>
 * /easytier portforward remove <tcp|udp> <bind_port>
 * /easytier portforward list
 * /easytier config list
 * /easytier config use <network_name>
 * /easytier config save
 * /easytier config delete <network_name>
 * /easytier autostart on [network_name]
 * /easytier autostart off
 * /easytier autostart status
 * /easytier reload
 *
 * 兼容旧形式: /easytier <network_name> <relay_server> [network_secret]
 */
public class EasyTierCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                class_2170.method_9247("easytier")
                        .requires(source -> source.method_9259(2))

                        // ===== start =====
                        .then(class_2170.method_9247("start")
                                .then(class_2170.method_9244("network_name", StringArgumentType.word())
                                        .then(class_2170.method_9244("relay_server", StringArgumentType.string())
                                                .executes(EasyTierCommand::startNoSecret)
                                                .then(class_2170.method_9244("network_secret", StringArgumentType.string())
                                                        .executes(EasyTierCommand::startWithSecret)))))

                        // ===== stop =====
                        .then(class_2170.method_9247("stop")
                                .executes(EasyTierCommand::stop))

                        // ===== status =====
                        .then(class_2170.method_9247("status")
                                .executes(EasyTierCommand::status))

                        // ===== peer =====
                        .then(class_2170.method_9247("peer")
                                .executes(EasyTierCommand::peer))

                        // ===== node =====
                        .then(class_2170.method_9247("node")
                                .executes(EasyTierCommand::node))

                        // ===== route =====
                        .then(class_2170.method_9247("route")
                                .executes(EasyTierCommand::route))

                        // ===== portforward =====
                        .then(class_2170.method_9247("portforward")
                                .then(class_2170.method_9247("add")
                                        .then(class_2170.method_9244("protocol", StringArgumentType.word())
                                                .then(class_2170.method_9244("bind_port", IntegerArgumentType.integer(1, 65535))
                                                        .then(class_2170.method_9244("virtual_ip", StringArgumentType.word())
                                                                .then(class_2170.method_9244("mc_port", IntegerArgumentType.integer(1, 65535))
                                                                        .executes(EasyTierCommand::portForwardAdd))))))
                                .then(class_2170.method_9247("remove")
                                        .then(class_2170.method_9244("protocol", StringArgumentType.word())
                                                .then(class_2170.method_9244("bind_port", IntegerArgumentType.integer(1, 65535))
                                                        .executes(EasyTierCommand::portForwardRemove))))
                                .then(class_2170.method_9247("list")
                                        .executes(EasyTierCommand::portForwardList)))

                        // ===== config =====
                        .then(class_2170.method_9247("config")
                                .then(class_2170.method_9247("list")
                                        .executes(EasyTierCommand::configList))
                                .then(class_2170.method_9247("use")
                                        .then(class_2170.method_9244("network_name", StringArgumentType.word())
                                                .executes(EasyTierCommand::configUse)))
                                .then(class_2170.method_9247("save")
                                        .executes(EasyTierCommand::configSave))
                                .then(class_2170.method_9247("delete")
                                        .then(class_2170.method_9244("network_name", StringArgumentType.word())
                                                .executes(EasyTierCommand::configDelete))))

                        // ===== reload =====
                        .then(class_2170.method_9247("reload")
                                .executes(EasyTierCommand::reload))

                        // ===== autostart =====
                        .then(class_2170.method_9247("autostart")
                                .executes(EasyTierCommand::autoStartStatus)
                                .then(class_2170.method_9247("on")
                                        .executes(ctx -> doAutoStart(ctx, true, null))
                                        .then(class_2170.method_9244("network_name", StringArgumentType.word())
                                                .executes(ctx -> doAutoStart(ctx, true,
                                                        StringArgumentType.getString(ctx, "network_name")))))
                                .then(class_2170.method_9247("off")
                                        .executes(ctx -> doAutoStart(ctx, false, null)))
                                .then(class_2170.method_9247("status")
                                        .executes(EasyTierCommand::autoStartStatus)))

                        // ===== 旧形式兼容: /easytier <name> <server> [secret] =====
                        .then(class_2170.method_9244("network_name", StringArgumentType.word())
                                .then(class_2170.method_9244("relay_server", StringArgumentType.string())
                                        .executes(EasyTierCommand::legacyStartNoSecret)
                                        .then(class_2170.method_9244("network_secret", StringArgumentType.string())
                                                .executes(EasyTierCommand::legacyStartWithSecret))))

                        // 无参数显示用法
                        .executes(EasyTierCommand::showUsage)
        );
    }

    // ==================== start ====================

    private static int startNoSecret(CommandContext<class_2168> ctx) {
        return doStart(ctx,
                StringArgumentType.getString(ctx, "network_name"),
                StringArgumentType.getString(ctx, "relay_server"),
                "");
    }

    private static int startWithSecret(CommandContext<class_2168> ctx) {
        return doStart(ctx,
                StringArgumentType.getString(ctx, "network_name"),
                StringArgumentType.getString(ctx, "relay_server"),
                StringArgumentType.getString(ctx, "network_secret"));
    }

    private static int legacyStartNoSecret(CommandContext<class_2168> ctx) {
        return doStart(ctx,
                StringArgumentType.getString(ctx, "network_name"),
                StringArgumentType.getString(ctx, "relay_server"),
                "");
    }

    private static int legacyStartWithSecret(CommandContext<class_2168> ctx) {
        return doStart(ctx,
                StringArgumentType.getString(ctx, "network_name"),
                StringArgumentType.getString(ctx, "relay_server"),
                StringArgumentType.getString(ctx, "network_secret"));
    }

    private static int doStart(CommandContext<class_2168> ctx,
                               String name, String relay, String secret) {
        EasyTierService service = EasyTierService.getInstance();

        // Android 阻断
        if (service.isAndroid()) {
            ctx.getSource().method_9213(class_2561.method_43470(
                    "EasyTier Fabric LAN 不支持 Android 平台。请使用 EasyTier 官方 Android 应用建立虚拟网络，然后在 Minecraft 中直接连接虚拟 IP。"));
            return 0;
        }
        if (!service.isPlatformSupported()) {
            ctx.getSource().method_9213(class_2561.method_43470("当前平台不支持 EasyTier"));
            return 0;
        }

        if (service.isRunning()) {
            ctx.getSource().method_9213(class_2561.method_43470("EasyTier 已在运行中，请先执行 /easytier stop"));
            return 0;
        }

        // 参数校验
        if (name == null || name.isEmpty() || name.length() > 32) {
            ctx.getSource().method_9213(class_2561.method_43470("网络名称必须为 1-32 个字符，允许字母、数字、下划线、连字符"));
            return 0;
        }
        if (!name.matches("[a-zA-Z0-9_-]+")) {
            ctx.getSource().method_9213(class_2561.method_43470("网络名称只能包含字母、数字、下划线、连字符"));
            return 0;
        }
        if (relay == null || relay.isEmpty()) {
            ctx.getSource().method_9213(class_2561.method_43470("中继服务器不能为空，格式 host:port 或 tcp://host:port"));
            return 0;
        }

        boolean ok = service.start(name, relay, secret, "et_fabric", true);
        if (ok) {
            String fileName = FileSanitizer.sanitize(name) + ".toml";
            ctx.getSource().method_9226(() -> class_2561.method_43470(
                    "EasyTier 已启动: " + name + " (" + fileName + ")"), true);
            return 1;
        } else {
            ctx.getSource().method_9213(class_2561.method_43470("EasyTier 启动失败，请查看日志"));
            return 0;
        }
    }

    // ==================== stop ====================

    private static int stop(CommandContext<class_2168> ctx) {
        EasyTierService service = EasyTierService.getInstance();
        if (!service.isRunning()) {
            ctx.getSource().method_9213(class_2561.method_43470("EasyTier 未在运行"));
            return 0;
        }
        service.stop();
        ctx.getSource().method_9226(() -> class_2561.method_43470("EasyTier 已停止"), true);
        return 1;
    }

    // ==================== status ====================

    private static int status(CommandContext<class_2168> ctx) {
        EasyTierService service = EasyTierService.getInstance();
        EasyTierProcessManager pm = service.getProcessManager();

        if (!service.isRunning()) {
            ctx.getSource().method_9226(() -> class_2561.method_43470("EasyTier 未运行"), false);
            return 1;
        }

        TomlConfig cfg = pm.getCurrentConfig();
        String name = cfg != null && cfg.getNetworkName() != null ? cfg.getNetworkName() : "?";
        String fileName = cfg != null ? cfg.toFileName() : "?";
        String ip = service.getVirtualIp();

        StringBuilder sb = new StringBuilder();
        sb.append("运行中: ").append(name).append("（").append(fileName).append("）");
        if (ip != null) {
            sb.append("，虚拟 IP ").append(ip);
        } else {
            sb.append("，虚拟 IP 待分配");
        }

        ctx.getSource().method_9226(() -> class_2561.method_43470(sb.toString()), false);
        return 1;
    }

    // ==================== peer / node / route ====================

    private static int peer(CommandContext<class_2168> ctx) {
        return runCliAndFeedback(ctx, "peer");
    }

    private static int node(CommandContext<class_2168> ctx) {
        return runCliAndFeedback(ctx, "node");
    }

    private static int route(CommandContext<class_2168> ctx) {
        return runCliAndFeedback(ctx, "route");
    }

    private static int runCliAndFeedback(CommandContext<class_2168> ctx, String command) {
        EasyTierService service = EasyTierService.getInstance();
        if (!service.isRunning()) {
            ctx.getSource().method_9213(class_2561.method_43470("EasyTier 未在运行"));
            return 0;
        }
        EasyTierCliRunner cli = service.getCliRunner();
        String output;
        switch (command) {
            case "peer": output = cli.peer(); break;
            case "node": output = cli.node(); break;
            case "route": output = cli.route(); break;
            default: output = "未知命令";
        }
        String finalOutput = output.isEmpty() ? "(无输出)" : output;
        ctx.getSource().method_9226(() -> class_2561.method_43470(finalOutput), false);
        return 1;
    }

    // ==================== portforward ====================

    private static int portForwardAdd(CommandContext<class_2168> ctx) {
        EasyTierService service = EasyTierService.getInstance();
        if (!service.isRunning()) {
            ctx.getSource().method_9213(class_2561.method_43470("EasyTier 未在运行"));
            return 0;
        }
        String protocol = StringArgumentType.getString(ctx, "protocol").toLowerCase();
        if (!protocol.equals("tcp") && !protocol.equals("udp")) {
            ctx.getSource().method_9213(class_2561.method_43470("协议必须是 tcp 或 udp"));
            return 0;
        }
        int bindPort = IntegerArgumentType.getInteger(ctx, "bind_port");
        String virtualIp = StringArgumentType.getString(ctx, "virtual_ip");
        int mcPort = IntegerArgumentType.getInteger(ctx, "mc_port");

        boolean ok = service.getProcessManager().addPortForward(protocol, bindPort, virtualIp, mcPort);
        if (ok) {
            ctx.getSource().method_9226(() -> class_2561.method_43470(
                    "端口转发已添加: " + protocol + " 0.0.0.0:" + bindPort + " -> " + virtualIp + ":" + mcPort), true);
            return 1;
        } else {
            ctx.getSource().method_9213(class_2561.method_43470("端口转发添加失败"));
            return 0;
        }
    }

    private static int portForwardRemove(CommandContext<class_2168> ctx) {
        EasyTierService service = EasyTierService.getInstance();
        if (!service.isRunning()) {
            ctx.getSource().method_9213(class_2561.method_43470("EasyTier 未在运行"));
            return 0;
        }
        String protocol = StringArgumentType.getString(ctx, "protocol").toLowerCase();
        int bindPort = IntegerArgumentType.getInteger(ctx, "bind_port");
        boolean ok = service.getProcessManager().removePortForward(protocol, bindPort);
        if (ok) {
            ctx.getSource().method_9226(() -> class_2561.method_43470(
                    "端口转发已移除: " + protocol + " 0.0.0.0:" + bindPort), true);
            return 1;
        } else {
            ctx.getSource().method_9213(class_2561.method_43470(
                    "端口转发移除失败: " + protocol + " 0.0.0.0:" + bindPort));
            return 0;
        }
    }

    private static int portForwardList(CommandContext<class_2168> ctx) {
        EasyTierService service = EasyTierService.getInstance();
        if (!service.isRunning()) {
            ctx.getSource().method_9213(class_2561.method_43470("EasyTier 未在运行"));
            return 0;
        }
        String output = service.getCliRunner().portForwardList();
        List<EasyTierProcessManager.PortForwardRule> rules = service.getProcessManager().getActivePortForwards();
        StringBuilder sb = new StringBuilder();
        if (!output.isEmpty() && !output.startsWith("错误")) {
            sb.append(output);
        }
        if (!rules.isEmpty()) {
            if (sb.length() > 0) sb.append("\n");
            sb.append("已添加的转发规则:\n");
            for (EasyTierProcessManager.PortForwardRule r : rules) {
                sb.append("  ").append(r.protocol).append(" 0.0.0.0:").append(r.bindPort)
                        .append(" -> ").append(r.virtualIp).append(":").append(r.mcPort).append("\n");
            }
        }
        if (sb.length() == 0) {
            sb.append("(无端口转发规则)");
        }
        String finalOutput = sb.toString();
        ctx.getSource().method_9226(() -> class_2561.method_43470(finalOutput), false);
        return 1;
    }

    // ==================== config ====================

    private static int configList(CommandContext<class_2168> ctx) {
        EasyTierService service = EasyTierService.getInstance();
        Map<String, TomlConfig> all = service.scanAllConfigs();
        if (all.isEmpty()) {
            ctx.getSource().method_9226(() -> class_2561.method_43470("(无配置文件)"), false);
            return 1;
        }
        StringBuilder sb = new StringBuilder("配置列表:\n");
        for (Map.Entry<String, TomlConfig> entry : all.entrySet()) {
            sb.append("  ").append(entry.getKey());
            TomlConfig cfg = entry.getValue();
            if (cfg.isCorrupted()) {
                sb.append(" [损坏]");
            } else {
                sb.append(" (").append(cfg.toFileName()).append(")");
            }
            sb.append("\n");
        }
        String finalOutput = sb.toString().trim();
        ctx.getSource().method_9226(() -> class_2561.method_43470(finalOutput), false);
        return 1;
    }

    private static int configUse(CommandContext<class_2168> ctx) {
        EasyTierService service = EasyTierService.getInstance();
        ConfigManager cm = service.getConfigManager();
        String name = StringArgumentType.getString(ctx, "network_name");

        if (!cm.configExists(name)) {
            ctx.getSource().method_9213(class_2561.method_43470(
                    "配置不存在: " + FileSanitizer.sanitize(name) + ".toml"));
            return 0;
        }

        TomlConfig cfg = cm.loadConfig(name);
        if (cfg == null || cfg.isCorrupted()) {
            ctx.getSource().method_9213(class_2561.method_43470("配置已损坏"));
            return 0;
        }

        String actualName = cfg.getNetworkName() != null && !cfg.getNetworkName().isEmpty()
                ? cfg.getNetworkName() : name;
        cm.writeActive(new ConfigManager.ActiveConfig(actualName, true));
        ctx.getSource().method_9226(() -> class_2561.method_43470(
                "已设置活动配置: " + actualName
                        + "\n文件: " + cfg.toFileName()
                        + "\n中继: " + (cfg.getRelayServer() != null ? cfg.getRelayServer() : "?")
                        + "\n密码: " + (cfg.getNetworkSecret() != null && !cfg.getNetworkSecret().isEmpty() ? "已设置" : "无")), false);
        return 1;
    }

    private static int configSave(CommandContext<class_2168> ctx) {
        EasyTierService service = EasyTierService.getInstance();
        EasyTierProcessManager pm = service.getProcessManager();
        TomlConfig current = pm.getCurrentConfig();
        if (current == null) {
            ctx.getSource().method_9213(class_2561.method_43470("当前没有运行中的配置"));
            return 0;
        }

        boolean ok = service.getConfigManager().saveConfig(current);
        if (ok) {
            ctx.getSource().method_9226(() -> class_2561.method_43470(
                    "配置已保存: " + current.toFileName()), true);
            return 1;
        } else {
            ctx.getSource().method_9213(class_2561.method_43470("保存失败"));
            return 0;
        }
    }

    private static int configDelete(CommandContext<class_2168> ctx) {
        EasyTierService service = EasyTierService.getInstance();
        ConfigManager cm = service.getConfigManager();
        String name = StringArgumentType.getString(ctx, "network_name");

        // 检查正在运行的配置
        if (service.isRunning() && service.getProcessManager().getCurrentConfig() != null) {
            TomlConfig running = service.getProcessManager().getCurrentConfig();
            if (name.equalsIgnoreCase(running.getNetworkName())) {
                ctx.getSource().method_9213(class_2561.method_43470("正在运行的配置无法删除，请先停止"));
                return 0;
            }
        }

        boolean ok = cm.deleteConfig(name);
        if (ok) {
            ctx.getSource().method_9226(() -> class_2561.method_43470(
                    "已删除: " + FileSanitizer.sanitize(name) + ".toml"), true);
            return 1;
        } else {
            ctx.getSource().method_9213(class_2561.method_43470(
                    "配置不存在: " + FileSanitizer.sanitize(name) + ".toml"));
            return 0;
        }
    }

    // ==================== reload ====================

    private static int reload(CommandContext<class_2168> ctx) {
        EasyTierService service = EasyTierService.getInstance();
        ConfigManager cm = service.getConfigManager();
        ConfigManager.ActiveConfig active = cm.readActive();
        if (active == null || active.network_name == null || !cm.configExists(active.network_name)) {
            // 兼容只用 /easytier autostart on 写入的世界级 active.json
            ConfigManager.ActiveConfig worldActive = cm.readWorldActive(currentWorldName(ctx));
            if (worldActive != null && worldActive.network_name != null) {
                active = worldActive;
            }
        }

        if (active == null || active.network_name == null) {
            ctx.getSource().method_9213(class_2561.method_43470(
                    "未设置活动配置，请先执行 /easytier config use <network_name>"));
            return 0;
        }

        if (!cm.configExists(active.network_name)) {
            ctx.getSource().method_9213(class_2561.method_43470(
                    "配置文件不存在: " + FileSanitizer.sanitize(active.network_name)
                            + ".toml，请执行 /easytier config list 查看可用配置"));
            return 0;
        }

        TomlConfig cfg = cm.loadConfig(active.network_name);
        if (cfg == null || cfg.isCorrupted()) {
            ctx.getSource().method_9213(class_2561.method_43470("配置文件已损坏"));
            return 0;
        }

        // 停止当前实例（如果在运行）
        if (service.isRunning()) {
            service.stop();
        }

        String name = cfg.getNetworkName() != null && !cfg.getNetworkName().isEmpty()
                ? cfg.getNetworkName() : active.network_name;
        boolean ok = service.start(
                name,
                cfg.getRelayServer() != null ? cfg.getRelayServer() : "",
                cfg.getNetworkSecret() != null ? cfg.getNetworkSecret() : "",
                cfg.getDevName() != null ? cfg.getDevName() : "et_fabric",
                cfg.isDhcp());

        if (ok) {
            ctx.getSource().method_9226(() -> class_2561.method_43470("已重启: " + name), true);
            return 1;
        } else {
            ctx.getSource().method_9213(class_2561.method_43470("重启失败，请查看日志"));
            return 0;
        }
    }

    // ==================== autostart ====================

    private static int autoStartStatus(CommandContext<class_2168> ctx) {
        EasyTierService service = EasyTierService.getInstance();
        ConfigManager cm = service.getConfigManager();
        String worldName = currentWorldName(ctx);

        boolean globalEnabled = cm.isAutoStartOnWorldLoad();
        ConfigManager.ActiveConfig active = cm.readWorldActive(worldName);

        StringBuilder sb = new StringBuilder();
        sb.append("服务器自启动开关: ").append(globalEnabled ? "开启" : "关闭");
        sb.append("\n世界: ").append(worldName);
        if (active != null && active.network_name != null && !active.network_name.isEmpty()) {
            sb.append("\n世界配置: ").append(active.network_name);
            if (!cm.configExists(active.network_name)) {
                sb.append("（配置文件不存在）");
            }
            sb.append("\n世界自启动: ").append(active.auto_start ? "开启" : "关闭");
        } else {
            sb.append("\n世界配置: 未设置");
        }

        String message = sb.toString();
        ctx.getSource().method_9226(() -> class_2561.method_43470(message), false);
        return 1;
    }

    private static int doAutoStart(CommandContext<class_2168> ctx,
                                   boolean enabled, String requestedName) {
        EasyTierService service = EasyTierService.getInstance();
        ConfigManager cm = service.getConfigManager();
        String worldName = currentWorldName(ctx);

        if (!enabled) {
            boolean switchOk = cm.setAutoStartOnWorldLoad(false);
            boolean worldOk = true;
            ConfigManager.ActiveConfig existing = cm.readWorldActive(worldName);
            if (switchOk && existing != null && existing.network_name != null && !existing.network_name.isEmpty()) {
                worldOk = cm.writeWorldActive(worldName, new ConfigManager.ActiveConfig(existing.network_name, false));
            }
            if (switchOk && worldOk) {
                ctx.getSource().method_9226(() -> class_2561.method_43470(
                        "已关闭服务器世界自启动（世界: " + worldName + "）"), true);
                return 1;
            } else {
                ctx.getSource().method_9213(class_2561.method_43470("关闭自启动失败，请检查 server.toml 写入权限"));
                return 0;
            }
        }

        String name = requestedName;
        if (name == null || name.isEmpty()) {
            TomlConfig current = service.getProcessManager().getCurrentConfig();
            if (current != null && current.getNetworkName() != null && !current.getNetworkName().isEmpty()) {
                name = current.getNetworkName();
            } else if (service.getCurrentNetworkName() != null && !service.getCurrentNetworkName().isEmpty()) {
                name = service.getCurrentNetworkName();
            }
        }
        if (name == null || name.isEmpty()) {
            List<String> configs = cm.listNetworkNames();
            if (configs.size() == 1) {
                name = configs.get(0);
            } else {
                String available = configs.isEmpty() ? "无" : String.join(", ", configs);
                ctx.getSource().method_9213(class_2561.method_43470(
                        "请指定网络配置: /easytier autostart on <网络名称>（可用配置: " + available + "）"));
                return 0;
            }
        }

        if (!cm.configExists(name)) {
            ctx.getSource().method_9213(class_2561.method_43470(
                    "配置不存在: " + FileSanitizer.sanitize(name) + ".toml"));
            return 0;
        }
        TomlConfig cfg = cm.loadConfig(name);
        if (cfg == null || cfg.isCorrupted()) {
            ctx.getSource().method_9213(class_2561.method_43470("配置已损坏: " + FileSanitizer.sanitize(name) + ".toml"));
            return 0;
        }
        if (cfg.getNetworkName() != null && !cfg.getNetworkName().isEmpty()) {
            name = cfg.getNetworkName();
        }

        boolean switchOk = cm.setAutoStartOnWorldLoad(true);
        boolean worldOk = switchOk && cm.writeWorldActive(worldName, new ConfigManager.ActiveConfig(name, true));
        if (switchOk && worldOk) {
            final String startedName = name;
            ctx.getSource().method_9226(() -> class_2561.method_43470(
                    "已开启服务器世界自启动: " + startedName + "（世界: " + worldName + "）"), true);
            return 1;
        } else {
            if (switchOk) {
                cm.setAutoStartOnWorldLoad(false);
            }
            ctx.getSource().method_9213(class_2561.method_43470("开启自启动失败，请检查配置目录写入权限"));
            return 0;
        }
    }

    private static String currentWorldName(CommandContext<class_2168> ctx) {
        MinecraftServer server = ctx.getSource().method_9211();
        if (server == null) {
            return "world";
        }
        String name = server.method_27728().method_150();
        return name != null && !name.isEmpty() ? name : "world";
    }

    // ==================== usage ====================

    private static int showUsage(CommandContext<class_2168> ctx) {
        String usage = """
                EasyTier 命令用法:
                /easytier start <网络名称> <中继服务器> [密码]  - 启动 EasyTier
                /easytier stop                                  - 停止 EasyTier
                /easytier status                                - 查看状态
                /easytier peer                                  - 查看节点列表
                /easytier node                                  - 查看本节点信息
                /easytier route                                 - 查看路由表
                /easytier portforward add <tcp|udp> <端口> <虚拟IP> <MC端口>
                /easytier portforward remove <tcp|udp> <端口>
                /easytier portforward list
                /easytier config list
                /easytier config use <网络名称>
                /easytier config save
                /easytier config delete <网络名称>
                /easytier autostart on [网络名称]
                /easytier autostart off
                /easytier autostart status
                /easytier reload
                兼容: /easytier <网络名称> <中继服务器> [密码]""";
        ctx.getSource().method_9226(() -> class_2561.method_43470(usage), false);
        return 1;
    }
}
