package com.easytier.fabric.lan.mixin;

import com.easytier.fabric.lan.EasyTierService;
import com.easytier.fabric.lan.client.EasyTierConfigScreen;
import com.easytier.fabric.lan.platform.PlatformDetector;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.nio.file.Path;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_500;

/**
 * 多人游戏主界面注入 EasyTier 状态按钮
 * 仅显示运行状态，点击打开配置界面
 */
@Mixin(class_500.class)
public abstract class MultiplayerScreenMixin extends class_437 {

    private class_4185 easyTierButton;
    private EasyTierService service;
    private int tickCounter = 0;

    protected MultiplayerScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void addEasyTierButton(CallbackInfo ci) {
        PlatformDetector.detect();
        if (!PlatformDetector.isSupported()) {
            return;
        }

        Path configDir = this.field_22787.field_1697.toPath().resolve("config").resolve("easytier-go");
        service = EasyTierService.getInstance(configDir);

        // 在屏幕右上角添加一个小的状态按钮
        int btnW = 90;
        int btnH = 18;
        int btnX = this.field_22789 - btnW - 8;
        int btnY = 6;

        easyTierButton = class_4185.method_46430(
                        class_2561.method_43470(getButtonLabel()),
                        btn -> {
                            if (this.field_22787 != null) {
                                this.field_22787.method_1507(new EasyTierConfigScreen(this));
                            }
                        })
                .method_46434(btnX, btnY, btnW, btnH)
                .method_46431();
        this.method_37063(easyTierButton);
    }

    private String getButtonLabel() {
        if (service == null) return "EasyTier";
        boolean running = service.isRunning();
        boolean pending = service.isStartPending();
        if (pending) return "EasyTier: 启动中";
        return running ? "EasyTier: 运行中" : "EasyTier: 已停止";
    }

    @Override
    public void method_25393() {
        super.method_25393();
        tickCounter++;
        if (tickCounter >= 100 && easyTierButton != null) {
            tickCounter = 0;
            easyTierButton.method_25355(class_2561.method_43470(getButtonLabel()));
        }
    }
}
