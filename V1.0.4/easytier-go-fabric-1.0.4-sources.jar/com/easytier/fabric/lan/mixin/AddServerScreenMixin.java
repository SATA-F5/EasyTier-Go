package com.easytier.fabric.lan.mixin;

import com.easytier.fabric.lan.client.AutoConnectConfig;
import com.easytier.fabric.lan.client.EasyTierConfigScreen;
import com.easytier.fabric.lan.platform.PlatformDetector;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.nio.file.Path;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_422;
import net.minecraft.class_437;
import net.minecraft.class_5676;

/**
 * 在"添加服务器/编辑服务器"界面中注入 EasyTier 联机配置按钮和自动连接开关
 * EasyTier 按钮紧贴"服务器资源包"按钮下方
 */
@Mixin(class_422.class)
public abstract class AddServerScreenMixin extends class_437 {

    private class_5676<Boolean> autoConnectToggle;
    private AutoConnectConfig autoConnectConfig;
    private class_342 addressField;

    protected AddServerScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void addEasyTierButton(CallbackInfo ci) {
        PlatformDetector.detect();
        if (!PlatformDetector.isSupported()) {
            return;
        }

        int cx = this.field_22789 / 2;

        // 初始化自动连接配置
        Path configDir = this.field_22787.field_1697.toPath().resolve("config").resolve("easytier-go");
        autoConnectConfig = new AutoConnectConfig(configDir);

        // 找到地址输入框（优先选择内容像地址的输入框，否则取最后一个输入框）
        class_342 lastField = null;
        for (var child : this.method_25396()) {
            if (child instanceof class_342 field) {
                lastField = field;
                String text = field.method_1882().trim();
                if (text.contains(":") || text.contains(".")) {
                    addressField = field;
                    break;
                }
            }
        }
        if (addressField == null) {
            addressField = lastField;
        }

        // 查找"服务器资源包"按钮作为锚点
        class_339 resourcePackButton = null;
        for (var child : this.method_25396()) {
            if (child instanceof class_339 widget) {
                String msg = widget.method_25369().getString();
                if (msg.contains("服务器资源包") || msg.contains("Server Resource Packs")
                        || msg.contains("资源包") || msg.contains("Resource Pack")) {
                    resourcePackButton = widget;
                    break;
                }
            }
        }

        // 计算 EasyTier 按钮位置：紧贴资源包按钮下方
        int buttonY;
        if (resourcePackButton != null) {
            buttonY = resourcePackButton.method_46427() + resourcePackButton.method_25364() + 4;
        } else {
            buttonY = this.field_22790 / 4 + 108;
        }

        // 将底部按钮（添加服务器/取消）下移，为 EasyTier 行腾出空间
        int shift = 44;
        for (var child : this.method_25396()) {
            if (child instanceof class_339 widget && widget.method_46427() > buttonY) {
                widget.method_46419(widget.method_46427() + shift);
            }
        }

        // EasyTier 配置按钮（左半，紧贴资源包按钮下方）
        class_4185 easyTierButton = class_4185.method_46430(
                        class_2561.method_43470("EasyTier 联机配置"),
                        btn -> {
                            if (this.field_22787 != null) {
                                this.field_22787.method_1507(new EasyTierConfigScreen(this));
                            }
                        })
                .method_46434(cx - 100, buttonY, 95, 20)
                .method_46431();
        this.method_37063(easyTierButton);

        // 自动连接开关（右半，与 EasyTier 按钮同行）
        String currentAddr = addressField != null ? addressField.method_1882().trim() : "";
        boolean autoEnabled = autoConnectConfig.isEnabled(currentAddr);
        autoConnectToggle = class_5676.<Boolean>method_32606(val ->
                        class_2561.method_43470(val ? "开" : "关"))
                .method_32620(List.of(true, false))
                .method_32619(autoEnabled)
                .method_32617(cx + 5, buttonY, 95, 20,
                        class_2561.method_43470("自动连接"),
                        (btn, val) -> {
                            if (addressField != null) {
                                String addr = addressField.method_1882().trim();
                                if (!addr.isEmpty()) {
                                    AutoConnectConfig.AutoConnectEntry entry = autoConnectConfig.get(addr);
                                    entry.enabled = val;
                                    autoConnectConfig.put(addr, entry);
                                }
                            }
                        });
        this.method_37063(autoConnectToggle);

        // 提示文字（EasyTier 行下方）
        int hintY = buttonY + 24;
        this.method_37063(new net.minecraft.class_7842(
                cx - 100, hintY, 200, 10,
                class_2561.method_43470("开启后连接服务器时自动启动 EasyTier 并转发端口"),
                this.field_22793));
    }
}
