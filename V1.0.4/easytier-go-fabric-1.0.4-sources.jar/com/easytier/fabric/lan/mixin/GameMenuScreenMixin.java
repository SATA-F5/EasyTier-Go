package com.easytier.fabric.lan.mixin;

import com.easytier.fabric.lan.client.EasyTierConfigScreen;
import com.easytier.fabric.lan.platform.PlatformDetector;
import net.minecraft.class_2561;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_433;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 在暂停菜单（ESC菜单）中注入 EasyTier 联机按钮
 * 位置：对局域网开放/选项行下方，保存并退出上方
 * 不依赖"对局域网开放"界面，开启局域网后仍可访问
 */
@Mixin(class_433.class)
public abstract class GameMenuScreenMixin extends class_437 {

    protected GameMenuScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void addEasyTierButton(CallbackInfo ci) {
        PlatformDetector.detect();
        if (!PlatformDetector.isSupported()) {
            return;
        }

        int centerX = this.field_22789 / 2;

        // 找到"保存并退回到标题屏幕"按钮，记录其Y坐标并下移24像素
        int quitButtonY = -1;
        int shift = 24;
        for (var child : this.method_25396()) {
            if (child instanceof class_339 widget) {
                String msg = widget.method_25369().getString();
                if (msg.contains("保存并退回") || msg.contains("退回到标题")
                        || msg.contains("Save and Quit") || msg.contains("退出游戏")) {
                    quitButtonY = widget.method_46427();
                    widget.method_46419(quitButtonY + shift);
                }
            }
        }

        // EasyTier 按钮放在原"保存并退出"位置（居中全宽按钮）
        // 如果没找到退出按钮，放在选项行下方
        int buttonY;
        if (quitButtonY > 0) {
            buttonY = quitButtonY;
        } else {
            buttonY = this.field_22790 / 4 + 104;
        }

        class_4185 easyTierButton = class_4185.method_46430(
                        class_2561.method_43470("EasyTier 联机配置"),
                        btn -> {
                            if (this.field_22787 != null) {
                                this.field_22787.method_1507(new EasyTierConfigScreen(this));
                            }
                        })
                .method_46434(centerX - 102, buttonY, 204, 20)
                .method_46431();

        this.method_37063(easyTierButton);
    }
}
