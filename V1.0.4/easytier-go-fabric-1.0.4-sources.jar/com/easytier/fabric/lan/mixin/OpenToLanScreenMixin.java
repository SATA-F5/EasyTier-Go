package com.easytier.fabric.lan.mixin;

import com.easytier.fabric.lan.client.EasyTierConfigScreen;
import com.easytier.fabric.lan.platform.PlatformDetector;
import net.minecraft.class_2561;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_436;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 在"对局域网开放"界面中注入 EasyTier 联机配置按钮
 * 位置：创建局域网世界 和 取消 按钮中间
 */
@Mixin(class_436.class)
public abstract class OpenToLanScreenMixin extends class_437 {

    protected OpenToLanScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void addEasyTierButton(CallbackInfo ci) {
        PlatformDetector.detect();
        if (!PlatformDetector.isSupported()) {
            return;
        }

        int centerX = this.field_22789 / 2;
        int buttonY = this.field_22790 - 28;

        // 原生布局：创建局域网世界 [centerX-155, w150]，取消 [centerX+5, w150]
        // 重新排布为三按钮：创建局域网世界 | EasyTier | 取消，窄屏时自动收缩
        int gap = 5;
        int totalW = Math.min(350, Math.max(240, this.field_22789 - 20));
        int midW = Math.min(60, Math.max(40, totalW / 5));
        int btnW = Math.max(40, (totalW - midW - gap * 2) / 2);
        totalW = btnW * 2 + midW + gap * 2;
        int startX = centerX - totalW / 2;

        int createX = startX;
        int easyTierX = startX + btnW + gap;
        int cancelX = startX + btnW + gap + midW + gap;

        // 遍历已有按钮，调整位置
        for (var child : this.method_25396()) {
            if (child instanceof class_339 widget) {
                String msg = widget.method_25369().getString();
                if (msg.contains("创建局域网世界") || msg.contains("Open to LAN") || msg.contains("对外开放")) {
                    widget.method_46421(createX);
                    widget.method_25358(btnW);
                } else if (msg.equals("取消") || msg.equals("Cancel")) {
                    widget.method_46421(cancelX);
                    widget.method_25358(btnW);
                }
            }
        }

        // EasyTier 按钮放在中间
        class_4185 easyTierButton = class_4185.method_46430(
                        class_2561.method_43470("EasyTier"),
                        btn -> {
                            if (this.field_22787 != null) {
                                this.field_22787.method_1507(new EasyTierConfigScreen(this));
                            }
                        })
                .method_46434(easyTierX, buttonY, midW, 20)
                .method_46431();

        this.method_37063(easyTierButton);
    }
}
